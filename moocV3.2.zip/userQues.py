from bs4 import BeautifulSoup
import re
import requests

def getUserQuestion(s):
    with open(s,'r',encoding='utf-8') as f:
        soup=BeautifulSoup(f,'html.parser')
    quesList=soup.find_all(class_='j-richTxt')
    #检查是不是img，不是的话直接保存，是的话只保存图片名
    count=0
    global questions
    questions=[]
    for i in quesList:
        pTag=i.p
        imgTag=pTag.img
        if imgTag!=None:
            question=reImg(imgTag).upper()
        elif imgTag==None:
            if pTag.span.string!=None: question=pTag.span.string
            elif pTag.span.next_element.string!=None: question=pTag.span.next_element.string
            elif pTag.span.next_element.next_element.string!=None: question=pTag.span.next_element.next_element.string
            question=str(question)
            headers = {
                'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
            }
            data={
                'content':question,
                'result':'',
                'chtoun':'中文 转 Unicode'
            }
            r=requests.post('https://tool.chinaz.com/tools/unicode.aspx',headers=headers,data=data)
            soupR=BeautifulSoup(r.text,'html.parser')
            question=str(soupR.find_all(id='result')[0].string)
            question =question.replace('\\' , '').upper()
        questions.append(question)
        count+=1
    
def reImg(s):
    src=s['src']
    pattern=re.compile(r'/(\w*\.(?:jpg|png))')
    img=pattern.findall(src)[0]
    return img

def checkNeed(s):
    #在s寻找每个list里的元素，如果list的元素包含在s里，就true
    s = s.replace('\\' , '').upper()
    for i in questions:
        #i belong s
        if s.find(i)!=-1:
            questions.remove(i)
            if len(questions)==0:return 'the last one'
            return 'yes'
    return 'no'

if __name__=='__main__':
    getUserQuestion('que.html')