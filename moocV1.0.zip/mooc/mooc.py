import selenium , time , json , re , requests , getpass
from selenium import webdriver
from bs4 import BeautifulSoup
from tabulate import tabulate


class Test:
    title_pattern = re.compile(r'title="(.*?)";')
    content_pattern = re.compile(r'answer=true;.*?content="(.*?)";')
    cookie = ''
    test_list = []
    param1 = ''

    def __init__(self , url , count , username , password):
        self.Answers = {}
        self.url = url
        self.count = count
        self.username = username
        self.password = password

    def login(self , chrome_driver):
        print('正在登陆...')
        chrome_driver.get('https://www.icourse163.org/member/login.htm')
        time.sleep(2)
        iframe = chrome_driver.find_element_by_tag_name('iframe')
        chrome_driver.switch_to.frame(iframe)
        button2 = chrome_driver.find_element_by_class_name("tab0")
        button2.click()
        phone = chrome_driver.find_element_by_id('phoneipt')
        phone.send_keys(self.username)
        time.sleep(0.5)
        pass_word = chrome_driver.find_elements_by_name('email')[1]
        pass_word.send_keys(self.password)
        time.sleep(1)
        login_button = chrome_driver.find_element_by_id('submitBtn')
        login_button.click()
        time.sleep(2)
        print('登陆成功!')
        cookie = chrome_driver.get_cookies()
        jsonCookies = json.dumps(cookie)
        with open('mooc_cookie.json' , 'w') as f:
            f.write(jsonCookies)
        with open('mooc_cookie.json' , 'r' , encoding='utf-8') as f:
            listCookies = json.loads(f.read())
        cookie = [item["name"] + "=" + item["value"]
                  for item in listCookies]
        cookiestr = '; '.join(item for item in cookie)
        Test.cookie = cookiestr

    def get_test_list(self , chrome_driver):
        print('正在获取测试列表...')
        test_list = []
        chrome_driver.get(self.url)
        time.sleep(3)
        html = chrome_driver.page_source
        soup = BeautifulSoup(html , 'html.parser')
        titles = soup.find_all(class_='j-name')
        buttons = chrome_driver.find_elements_by_class_name('u-btn-default')
        amount = len(titles)
        for i in range(amount):
            titles[i] = titles[i].text
        for i in range(0 , amount):
            buttons[i].click()
            time.sleep(0.5)
            current_url = chrome_driver.current_url
            test_list.append([i + 1 , titles[i] , current_url[-10:]])
            chrome_driver.get(self.url)
            time.sleep(0.5)
            buttons = chrome_driver.find_elements_by_class_name('u-btn-default')
        print('获取测试列表成功!')
        print(tabulate(test_list , headers=['序号' , '测试名' , 'id'] , tablefmt='grid'))
        Test.test_list = test_list

    def get_param(self , loc , chrome_driver):
        url = self.url[:-8] + 'quiz?id=' + Test.test_list[loc][2]
        chrome_driver.get(url)
        time.sleep(2)
        start_button = chrome_driver.find_element_by_class_name('u-btn-primary')
        start_button.click()
        time.sleep(2)
        submit_button = chrome_driver.find_element_by_class_name('j-submitBtn')
        submit_button.click()
        sure_button = chrome_driver.find_element_by_class_name('j-ok-txt')
        sure_button.click()
        time.sleep(2)
        url = chrome_driver.current_url
        para1 = re.search('aid=(.*)' , url).group(1)
        Test.param1 = para1

    def __get_content(self , loc):
        data = {
            'callCount': '1' ,
            'scriptSessionId': '${scriptSessionId}190' ,
            'httpSessionId': '955ed742170d4ecc8d0d99638ea1ec94' ,
            'c0-scriptName': 'MocQuizBean' ,
            'c0-methodName': 'getQuizPaperDto' ,
            'c0-id': '0' ,
            'c0-param0': Test.test_list[loc][2] ,
            'c0-param1': Test.param1 ,
            'c0-param2': 'true' ,
            'batchId': str(int((time.time()) * 1000))
        }
        headers = {
            'cookie': self.cookie ,
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
        }
        url = 'https://www.icourse163.org/dwr/call/plaincall/MocQuizBean.getQuizPaperDto.dwr'
        content = requests.post(url , headers=headers , data=data).text
        return content

    def get_answer(self , loc , chrome_driver):
        print(Test.test_list[loc][1])
        for time in range(self.count):
            print('第%d次刷题' % (time + 1))
            self.get_param(loc , chrome_driver)
            content = self.__get_content(loc)
            questions = re.findall(self.title_pattern , content)
            answers = re.findall(self.content_pattern , content)
            count = 0
            answer_dict = {}
            for i in questions:
                answer_dict[i] = answers[count]
                count += 1
            for answer in answer_dict:
                if answer not in self.Answers:
                    self.Answers[answer] = answer_dict[answer]

    def write_html(self , filename):
        print('正在写入答案...')
        dict = self.Answers
        File = open(filename + '.html' , 'w' , encoding='utf-8')
        head = '''<html>
        <table border="1">
        <tr><td>序号</td><td>题目</td><td>答案</td>
        '''
        tail = '''</table>
        </html>
        '''
        File.write(head)
        count = 1
        for i in dict:
            if 'http' in i:
                title = i.replace('\\' , '')
            else:
                soup = BeautifulSoup(i , 'html.parser')
                title = soup.find('p').text
                title = '''　<script>
                document.write("%s") 
            </script>''' % title
            if 'http' in dict[i]:
                dict[i] = dict[i].replace('\\' , '')
            else:
                soup = BeautifulSoup(dict[i] , 'html.parser')
                dict[i] = soup.find('p').text
                dict[i] = '''　<script>
    document.write("%s") 
</script>''' % (dict[i])
            line = '<tr><td>' + str(count) + '</td><td>' + title + '</td><td>' + dict[
                i] + '</td></tr>'
            File.write(line)
            count += 1
        File.write(tail)
        File.close()
        print('写入成功,欢迎再次使用!')


print('欢迎使用iCourse刷答案程序 V1.0')
time.sleep(1)
url = input('请输入测试列表URL')
username = input('请输入手机号码')
password = getpass.getpass('请输入密码')
# password = input('请输入密码')
count = eval(input('请根据实际情况选择单个测试刷题次数'))
chrome_driver = webdriver.Chrome()
test = Test(url , count , username , password)
test.login(chrome_driver)
test.get_test_list(chrome_driver)
loc = eval(input('请输入要刷答案的测试序号,AllIn请输入0:')) - 1
print('开始刷答案...')
if loc >= 0:
    filename = Test.test_list[loc][1]
    test.get_param(loc , chrome_driver)
    test.get_answer(loc , chrome_driver)
    test.write_html(filename)
else:
    for i in range(len(Test.test_list)):
        test = Test(url , count , username , password)
        test.get_answer(i , chrome_driver)
        filename = Test.test_list[i][1]
        test.write_html(filename)
chrome_driver.close()
