import selenium , time , json , re , requests , getpass
from selenium import webdriver
from bs4 import BeautifulSoup
from tabulate import tabulate


class Test :
    title_pattern = re.compile(r'title="(.*?)";')
    content_pattern = re.compile(r'answer=true;.*?content="(.*?)";')
    pattern = re.compile(r'contentId=(.*?);.*?isTestChecked=true.*?name="(.*?)"')
    cookie = ''
    test_list = []
    param1 = ''

    def __init__(self , url , count , username , password) :
        self.Answers = {}
        self.url = url
        self.count = count
        self.username = username
        self.password = password

    def login(self , chrome_driver) :
        print('正在登陆...')
        chrome_driver.get('https://www.icourse163.org/member/login.htm')
        # chrome_driver.minimize_window()
        time.sleep(2)
        iframe = chrome_driver.find_element_by_tag_name('iframe')
        chrome_driver.switch_to.frame(iframe)
        button2 = chrome_driver.find_element_by_class_name("tab0")
        button2.click()
        phone = chrome_driver.find_element_by_id('phoneipt')
        phone.send_keys(self.username)
        time.sleep(0.5)
        pass_word = chrome_driver.find_elements_by_name('email')[1]
        pass_word.send_keys(self.password)
        time.sleep(1)
        login_button = chrome_driver.find_element_by_id('submitBtn')
        login_button.click()
        time.sleep(2)
        print('登陆成功!')
        cookie = chrome_driver.get_cookies()
        jsonCookies = json.dumps(cookie)
        with open('mooc_cookie.json' , 'w') as f :
            f.write(jsonCookies)
        with open('mooc_cookie.json' , 'r' , encoding='utf-8') as f :
            listCookies = json.loads(f.read())
        cookie = [item["name"] + "=" + item["value"]
                  for item in listCookies]
        cookiestr = '; '.join(item for item in cookie)
        Test.cookie = cookiestr

    def get_test_list(self) :
        print('正在获取测试列表...')
        url = ' https://www.icourse163.org/dwr/call/plaincall/TermBean.getNewestItems.dwr'
        headers = {
            'cookie' : self.cookie ,
            'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
        }
        data = {
            'callCount' : '1' ,
            'scriptSessionId' : '${scriptSessionId}190' ,
            'httpSessionId' : '955ed742170d4ecc8d0d99638ea1ec94' ,
            'c0-scriptName' : 'CourseBean' ,
            'c0-methodName' : 'getLastLearnedMocTermDto' ,
            'c0-id' : '0' ,
            'c0-param0' : re.search(r'tid=(.*?)#' , self.url).group(1) ,
            'batchId' : str(int((time.time()) * 1000))
        }

        res = requests.post(url , data=data , headers=headers)
        content = res.text
        names = re.findall(self.pattern , content)

        test_list = []
        for i in range(len(names)) :
            test_list.append([i + 1 , names[i][1].encode('utf-8').decode('unicode_escape') , names[i][0]])
        print('获取测试列表成功!')
        print(tabulate(test_list , headers=['序号' , '测试名' , 'id'] , tablefmt='grid'))
        Test.test_list = test_list

    def get_param(self , loc , chrome_driver) :
        url = self.url[:-8] + 'quiz?id=' + Test.test_list[loc][2]
        chrome_driver.get(url)
        time.sleep(2)
        start_button = chrome_driver.find_element_by_class_name('u-btn-primary')
        start_button.click()
        time.sleep(2)
        submit_button = chrome_driver.find_element_by_class_name('j-submitBtn')
        submit_button.click()
        sure_button = chrome_driver.find_element_by_class_name('j-ok-txt')
        sure_button.click()
        time.sleep(2)
        url = chrome_driver.current_url
        para1 = re.search('aid=(.*)' , url).group(1)
        Test.param1 = para1

    def __get_content(self , loc) :
        data = {
            'callCount' : '1' ,
            'scriptSessionId' : '${scriptSessionId}190' ,
            'httpSessionId' : '955ed742170d4ecc8d0d99638ea1ec94' ,
            'c0-scriptName' : 'MocQuizBean' ,
            'c0-methodName' : 'getQuizPaperDto' ,
            'c0-id' : '0' ,
            'c0-param0' : Test.test_list[loc][2] ,
            'c0-param1' : Test.param1 ,
            'c0-param2' : 'true' ,
            'batchId' : str(int((time.time()) * 1000))
        }
        headers = {
            'cookie' : self.cookie ,
            'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
        }
        url = 'https://www.icourse163.org/dwr/call/plaincall/MocQuizBean.getQuizPaperDto.dwr'
        content = requests.post(url , headers=headers , data=data).text
        return content

    def get_answer(self , loc , chrome_driver) :
        print(Test.test_list[loc][1])
        for time in range(self.count) :
            print('第%d次刷题' % (time + 1))
            self.get_param(loc , chrome_driver)#编号
            content = self.__get_content(loc)#答案界面
            questions = re.findall(self.title_pattern , content)
            answers = re.findall(self.content_pattern , content)
            count = 0
            answer_dict = {}
            for i in questions :
                answer_dict[i] = answers[count]
                count += 1
            for answerTitle in answer_dict :
                if answerTitle not in self.Answers :
                    self.Answers[answerTitle] = answer_dict[answerTitle]

    def write_html(self , filename) :
        print('正在写入答案...')
        dict = self.Answers
        File = open(filename + '.html' , 'w' , encoding='utf-8')
        head = '''<html>
        <table border="1">
        <tr><td>序号</td><td>题目</td><td>答案</td>
        '''
        tail = '''</table>
        </html>
        '''
        File.write(head)
        count = 1
        for i in dict :
            if 'http' in i :
                title = i.replace('\\' , '')
            else :
                title = ''
                soup = BeautifulSoup(i , 'html.parser')
                txt = soup.find_all('p')
                for a in txt :
                    title += a.text
                title = '''　<script>
                document.write("%s") 
            </script>''' % title
            if 'http' in dict[i] :
                dict[i] = dict[i].replace('\\' , '')
            else :
                if dict[i]=='\\u9519\\u8BEF':dict[i]='<p>错误</p>'
                if dict[i]=='\\u6B63\\u786E':dict[i]='<p>正确</p>'
                content = ''
                soup = BeautifulSoup(dict[i] , 'html.parser')
                txt = soup.find_all('p')
                for a in txt :
                    content += a.text
                dict[i] = '''　<script>
    document.write("%s") 
</script>''' % content
            line = '<tr><td>' + str(count) + '</td><td>' + title + '</td><td>' + dict[
                i] + '</td></tr>'
            File.write(line)
            count += 1
        File.write(tail)
        File.close()
        print('写入成功!')


print('欢迎使用iCourse刷答案程序 V3.1')
time.sleep(1)
username = input('请输入手机号码')
password = getpass.getpass('请输入密码')
url = input('请输入测试列表URL:')
chrome_driver = webdriver.Chrome()
test = Test(url , 1 , username , password)
test.login(chrome_driver)
test.get_test_list()
tub=eval('('+input('请输入要刷答案的测试序号,逗号隔开(英文符号)，AllIn请输入0:')+',)')
count = eval(input('请根据实际情况选择单个测试刷题次数:'))
print('开始刷答案...')
for i in tub :
    i-=1
    test = Test(url , count , username , password)
    test.get_answer(i , chrome_driver)
    filename = Test.test_list[i][1]
    test.write_html(filename)
chrome_driver.quit()
print('即将退出,欢迎再次使用！')
time.sleep(1)
exit()
